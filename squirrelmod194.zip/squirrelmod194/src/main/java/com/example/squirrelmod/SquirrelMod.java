package com.example.squirrelmod;

import com.example.squirrelmod.entity.SquirrelEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class SquirrelMod implements ModInitializer {
    public static final String MOD_ID = "squirrelmod";

    public static final EntityType<SquirrelEntity> SQUIRREL = Registry.register(
            Registries.ENTITY_TYPE, new Identifier(MOD_ID, "squirrel"),
            FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, SquirrelEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.6f))
                    .build());

    public static final Item CHEKUSHKA = Registry.register(
            Registries.ITEM, new Identifier(MOD_ID, "chekushka"),
            new Item(new FabricItemSettings().maxCount(16)));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(SQUIRREL, SquirrelEntity.createSquirrelAttributes());

        SpawnRestriction.register(SQUIRREL, SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, SquirrelEntity::canSpawn);

        // Леса: часто, группы по 2-4. Тайга: редко.
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_FOREST),
                SpawnGroup.CREATURE, SQUIRREL, 40, 2, 4);
        BiomeModifications.addSpawn(BiomeSelectors.tag(BiomeTags.IS_TAIGA),
                SpawnGroup.CREATURE, SQUIRREL, 3, 1, 2);

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS)
                .register(entries -> entries.add(CHEKUSHKA));
    }
}
