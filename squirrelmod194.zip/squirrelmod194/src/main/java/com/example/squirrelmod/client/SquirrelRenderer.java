package com.example.squirrelmod.client;

import com.example.squirrelmod.SquirrelMod;
import com.example.squirrelmod.entity.SquirrelEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class SquirrelRenderer extends MobEntityRenderer<SquirrelEntity, SquirrelModel> {
    private static final Identifier TEXTURE =
            new Identifier(SquirrelMod.MOD_ID, "textures/entity/squirrel.png");

    public SquirrelRenderer(EntityRendererFactory.Context context) {
        super(context, new SquirrelModel(context.getPart(SquirrelModel.LAYER)), 0.3f);
    }

    @Override
    public Identifier getTexture(SquirrelEntity entity) {
        return TEXTURE;
    }
}
